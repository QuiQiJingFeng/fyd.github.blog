#ifndef __GLVIEW__
#define __GLVIEW__

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>

class GLView
{
public:
	GLView(int width, int height, char* title, int majorVersion = 3, int minorVersion = 3, int mode = GLFW_OPENGL_CORE_PROFILE);
	
	void setViewPort(float x, float y, float width, float height);
	void registerKeyPadEvent(GLFWkeyfun key_pad_func);
	void registerMouseEvent(GLFWcursorposfun mouse_func);
	void registerMouseWheelEvent(GLFWscrollfun mouse_wheel_func);
	void registerFrameSizeChangeEvent(GLFWframebuffersizefun frame_size_change_func);

	bool isViewShouldClose();

	void swapBuffers();
 
	void init();
private:
	GLFWwindow* _window;
	int _width;
	int _height;
	std::string _title;
	int _majorVersion;
	int _minorVersion;
	int _mode;
};
#endif