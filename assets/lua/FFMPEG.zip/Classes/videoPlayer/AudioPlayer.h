#ifndef __AUDIO_PLAYER_H
#define __AUDIO_PLAYER_H
#include "cocos2d.h"
#include "VideoContext.h"

class AudioPlayer : public cocos2d::Node
{
public:
    static AudioPlayer* getInstance();
    void dispose();

    AudioPlayer();
    ~AudioPlayer();

    bool init(Node* parent);
    bool nextFrame();
    bool parsePacket();
    void step(float dt);
 

private:
    float _totalTime;
    float _packetTime;
    AVPacket * _packet;
    bool _finish;
    AVFrame	* _pFrame;
	static AudioPlayer * __instance;
    int _gotAudio;
    uint8_t* _sambuf;
	struct SwrContext* _swr_covert_ctx
 
};
#endif