#ifndef __VIDEO_PLAYER_H
#define __VIDEO_PLAYER_H
#include "cocos2d.h"
USING_NS_CC;
#include "VideoContext.h"
#include "VideoInfo.h"
#include "PicturePlayer.h"
class VideoPlayer : public Layer
{
public:
    ~VideoPlayer()
    {
		VideoInfo::getInstance()->dispose();
        VideoContext::getInstance()->dispose();
    }
    static VideoPlayer* create(float width,float height)
    {
        auto ret = new (std::nothrow) VideoPlayer();
        if(ret && ret->init(width,height))
            return ret;
        else{
            delete ret;
            return nullptr;
        }
    }
	bool init(float width,float height){
        _width = width;    //视频播放器的宽度 PS:跟视频的宽高不是一码事
        _height = height;  //视频播放器的高度
		return true;
    };

    bool play(std::string url)
    {
        _url = url;
		VideoContext::getInstance()->init();

		if (!VideoInfo::getInstance()->init(url))
			return false;
        if(!PicturePlayer::getInstance()->init(this))
            return false;
        
        auto pFormatCtx = VideoContext::getInstance()->getFormatContext(); 
        //Output Info-----------------------------
        printf("---------------- File Information ---------------\n");
        av_dump_format(pFormatCtx, 0, url.c_str(), 0);
        printf("-------------------------------------------------\n");

        this->scheduleUpdate();

		return true;
    };
    void VideoPlayer::update(float delta)
    {
        PicturePlayer::getInstance()->step(delta);
        if(PicturePlayer::getInstance()->isFinish()){
            this->unscheduleUpdate();
        }
    };

private:
    float _width,_height;
    std::string _url;
    
    VideoInfo* _videoInfo;

    struct SwsContext * _img_convert_ctx;
    AVPacket * _packet;
};
#endif