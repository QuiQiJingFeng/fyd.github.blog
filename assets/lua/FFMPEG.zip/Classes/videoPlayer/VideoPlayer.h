#ifndef __VIDEO_PLAYER__H
#define __VIDEO_PLAYER__H
#include "cocos2d.h"
#ifdef _WIN32
//Windows
extern "C"
{
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
#include "libavutil/imgutils.h"
#include "SDL2/SDL.h"
};
#else
//Linux...
#ifdef __cplusplus
extern "C"
{
#endif
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libavutil/imgutils.h>
#include <SDL2/SDL.h>
#ifdef __cplusplus
};
#endif
#endif
class VideoPlayer :public cocos2d::Layer
{
public:
	VideoPlayer();
	~VideoPlayer();
	CREATE_FUNC(VideoPlayer)
	bool init();

	bool play(std::string path);
	void update(float delta);
	int VideoPlayer::decodeFrame(AVFrame *frame, int src_width, int src_height, AVPixelFormat src_pix_fmt, int dst_width, int dst_height);
private:
	float _totalTime;
	std::string _path;
	AVFormatContext	* _pFormatCtx;
	struct SwsContext * _img_convert_ctx;
	AVFrame	* _pFrame;
	AVFrame * _pFrameYUV;
	AVFrame * _pFrameRGBA;
	AVPacket * _packet;
	int	 _videoindex;
	AVCodecContext	* _pCodecCtx;
	int _got_picture;
	cocos2d::Sprite * _sp;
	cocos2d::Image * _image;
	BYTE * _outBuff;
};

#endif