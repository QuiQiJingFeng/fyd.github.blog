#include "cocos2d.h"
#ifndef __VIDEO_CONTEXT_H
#define __VIDEO_CONTEXT_H
#ifdef _WIN32
//Windows
extern "C"
{
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"
#include "libavutil/imgutils.h"
#include "libavdevice/avdevice.h"
};
#else
//Linux...
#ifdef __cplusplus
extern "C"
{
#endif
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libswresample/swresample.h>
#include <libavutil/imgutils.h>
#include <libavdevice/avdevice.h>
#ifdef __cplusplus
};
#endif
#endif

class VideoContext
{
public:
    static VideoContext* getInstance();
	VideoContext();
    bool init();

    AVFormatContext	* getFormatContext();

    void dispose();
private:
    AVFormatContext	* _pFormatCtx;
	static VideoContext * __instance;
};
#endif