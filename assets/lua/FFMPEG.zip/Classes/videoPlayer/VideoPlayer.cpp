#include "VideoPlayer.h"
USING_NS_CC;
#undef PixelFormat
VideoPlayer::VideoPlayer() :_totalTime(0), _sp(nullptr), _outBuff(nullptr)
{

}
VideoPlayer::~VideoPlayer()
{
	sws_freeContext(_img_convert_ctx);
	av_frame_free(&_pFrameYUV);
	av_frame_free(&_pFrame);
	av_frame_free(&_pFrameRGBA);
	av_free(_outBuff);
	avcodec_close(_pCodecCtx);
	avformat_close_input(&_pFormatCtx);
	CC_SAFE_RELEASE(_image);
 
}

bool VideoPlayer::init()
{
	return true;
}

bool VideoPlayer::play(std::string path)
{
	_path = path;
	_totalTime = 0;
	_image = new (std::nothrow) Image();
 
 
	const char* filepath = path.c_str();
	//��ʼ��libavformat��ע������muxer��demuxer��Э��.  ��������ô˺����������ѡ����ϣ��֧�ֵĸ�ʽ
	av_register_all();
	//�������������ȫ�ֳ�ʼ��
	avformat_network_init();
	//����һ��AVFormatContext�����Ļ���
	_pFormatCtx = avformat_alloc_context();

	// �����뷽ʽ��һ��ý���ļ�,Ҳ��Դ�ļ�,codecs��û�д�,ֻ��ȡ���ļ���ͷ��Ϣ.
	if (avformat_open_input(&_pFormatCtx, filepath, NULL, NULL) != 0){
		printf("Couldn't open input stream.\n");
		return false;
	}

	//��ȡ��Ƶ�ļ���Ϣ
	if (avformat_find_stream_info(_pFormatCtx, NULL)<0){
		printf("Couldn't find stream information.\n");
		return false;
	}

	//��ȡ��Ƶ��Ӧ��steam_index  ,����ǻ�ȡ����Ƶ��ΪAVMEDIA_TYPE_AUDIO
	_videoindex = -1;
	for (int i = 0; i<_pFormatCtx->nb_streams; i++)
	if (_pFormatCtx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO){
		_videoindex = i;
		break;
	}
	if (_videoindex == -1){
		printf("Didn't find a video stream.\n");
		return false;
	}
	_pCodecCtx = _pFormatCtx->streams[_videoindex]->codec;
	AVCodec * pCodec = avcodec_find_decoder(_pCodecCtx->codec_id);
	if (pCodec == NULL){
		printf("Codec not found.\n");
		return false;
	}
	if (avcodec_open2(_pCodecCtx, pCodec, NULL)<0){
		printf("Could not open codec.\n");
		return false;
	}
	_pFrame = av_frame_alloc();
	_pFrameYUV = av_frame_alloc();
	_pFrameRGBA = av_frame_alloc();

	unsigned char *out_buffer = (unsigned char *)av_malloc(av_image_get_buffer_size(AV_PIX_FMT_YUV420P, _pCodecCtx->width, _pCodecCtx->height, 1));
	av_image_fill_arrays(_pFrameYUV->data, _pFrameYUV->linesize, out_buffer,
		AV_PIX_FMT_YUV420P, _pCodecCtx->width, _pCodecCtx->height, 1);

	//Output Info-----------------------------
	printf("---------------- File Information ---------------\n");
	av_dump_format(_pFormatCtx, 0, filepath, 0);
	printf("-------------------------------------------------\n");

	_img_convert_ctx = sws_getContext(_pCodecCtx->width, _pCodecCtx->height, _pCodecCtx->pix_fmt,
		_pCodecCtx->width, _pCodecCtx->height, AV_PIX_FMT_YUV420P, SWS_BICUBIC, NULL, NULL, NULL);

	int screen_w = _pCodecCtx->width;
	int screen_h = _pCodecCtx->height;
 
	_packet = (AVPacket *)av_malloc(sizeof(AVPacket));

	this->scheduleUpdate();

	//��������ʱ���
	_pFormatCtx->flags | AVFMT_FLAG_GENPTS;
	return true;
}

/**
* ����AVFrame�е�yuv420���ݲ���ת��Ϊrgba����
*
* @param frame ��Ҫ�����֡�ṹ
* @param src_width ��Ҫת����֡����
* @param src_height ��Ҫת����֡�߶�
* @param src_pix_fmt ��Ҫת����֡���뷽ʽ
* @param dst_width ת����Ŀ��Ŀ���
* @param dst_height ת����Ŀ��ĸ߶�
* @return
*
**/
int VideoPlayer::decodeFrame(AVFrame *frame, int src_width, int src_height,
	AVPixelFormat src_pix_fmt, int dst_width, int dst_height) {
	struct SwsContext *pSwsCtx;
	//// ת�����֡�ṹ����
	//AVFrame *dst_frameRGBA = NULL;
	//// Ŀ��֡�ṹ��ʼ��
	//dst_frameRGBA = av_frame_alloc();

 
	// ��ʼ��Ŀ��֡����
	int dst_frame_size;
	// ����RGBA�µ�Ŀ�곤��
	dst_frame_size = avpicture_get_size(AV_PIX_FMT_RGBA, dst_width, dst_height);
	// ����ת����������ڴ�ռ�
	if (_outBuff == nullptr)
		_outBuff = (uint8_t *)av_malloc(dst_frame_size);
	// ��ʼ��Ŀ��֡
	avpicture_fill((AVPicture *)_pFrameRGBA, _outBuff, AV_PIX_FMT_RGBA,
		dst_width, dst_height);

	// ��ȡ����������
	pSwsCtx = sws_getContext(src_width, src_height, src_pix_fmt, dst_width, dst_height, AV_PIX_FMT_RGBA,
		SWS_BICUBIC, NULL, NULL, NULL);
	// ���ţ����������Ŀ��֡�ṹ��dst_frameRGBA->data��
	sws_scale(pSwsCtx, frame->data,
		frame->linesize, 0, src_height,
		_pFrameRGBA->data, _pFrameRGBA->linesize);
	return dst_frame_size;
}
/**
* ����rgb����
* @param data
* @param frameSize
* */
void save_rgb(uint8_t *data, int frameSize) {

	FILE *pFile;
	char *szFilename = "E:/cocos_310_projects/testFFmpeg/rgbdata";
	int y;

	pFile = fopen(szFilename, "wb");

	if (pFile == NULL)
		return;

	//д���ļ�
	fwrite(data, 1, frameSize, pFile);

	// Close file
	fclose(pFile);

}
void VideoPlayer::update(float delta)
{
	_totalTime += delta;
 
	if (_totalTime > 0.04){
		_totalTime = 0;
		while (1){
			if (av_read_frame(_pFormatCtx, _packet) < 0)
			{
				this->unscheduleUpdate();
				return;
			}

			if (_packet->stream_index == _videoindex)
				break;
		}
		

		int ret = avcodec_decode_video2(_pCodecCtx, _pFrame, &_got_picture, _packet);
		if (ret < 0){
			printf("Decode Error.\n");
			this->unscheduleUpdate();
			return;
		}
		if (_got_picture){
			int dst_frame_size = this->decodeFrame(_pFrame, _pFrame->width, _pFrame->height, AV_PIX_FMT_YUV420P, _pCodecCtx->width, _pCodecCtx->height);
 
			


			if (_sp == nullptr)
			{
				bool isOK = _image->initWithRawData(_pFrameRGBA->data[0], dst_frame_size, _pCodecCtx->width, _pCodecCtx->height, 8);
				CC_UNUSED_PARAM(isOK);
				CCASSERT(isOK, "The 2x2 empty texture was created unsuccessfully.");

				auto texture2D = new (std::nothrow) Texture2D();
				texture2D->initWithImage(_image);
				texture2D->autorelease();


				Size visibleSize = Director::getInstance()->getVisibleSize();
				Vec2 origin = Director::getInstance()->getVisibleOrigin();
				// add "HelloWorld" splash screen"
				_sp = Sprite::createWithTexture(texture2D);
				_sp->setContentSize(Size(_pCodecCtx->width, _pCodecCtx->height));
				// position the sprite on the center of the screen
				_sp->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));

				// add the sprite as a child to this layer
				this->addChild(_sp, 0);

				float scale = 0;
				if (scale < visibleSize.width / _pCodecCtx->width){
					scale = visibleSize.width / _pCodecCtx->width;
				}
				if (scale < visibleSize.height / _pCodecCtx->height){
					scale = visibleSize.height / _pCodecCtx->height;
				}
				_sp->setScale(scale);

			}
			else
			{
				bool isOK = _image->updateWithRawData(_pFrameRGBA->data[0], dst_frame_size, _pCodecCtx->width, _pCodecCtx->height, 8);
				CC_UNUSED_PARAM(isOK);
				CCASSERT(isOK, "The 2x2 empty texture was created unsuccessfully.");
				_sp->getTexture()->initWithImage(_image);
				/*auto texture2D = new (std::nothrow) Texture2D();
				texture2D->initWithImage(_image);
				texture2D->autorelease();
				_sp->setTexture(texture2D);*/
			}
			
 
		}
		av_free_packet(_packet);
	}
}
