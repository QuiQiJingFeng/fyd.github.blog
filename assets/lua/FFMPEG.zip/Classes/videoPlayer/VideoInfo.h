#ifndef __VIDEO_INFO_H
#define __VIDEO_INFO_H
#include "VideoContext.h"


class VideoInfo
{
public:
    static VideoInfo* getInstance();
    void dispose();

    bool init(std::string url);

    //获取视频码率 视频码率就是数据传输时单位时间传送的数据位数，一般我们用的单位是kbps即千位每秒。通俗一点的理解就是取样率
    //单位kb/s
	float getBitRate();

    //获取视频总时长 字符串型
    //@needUs 是否需要将毫秒也放进去
    std::string getTotalTime(bool needUs);

    //打开视频解码器
    bool openVideoCodec();

    //打开音频解码器
    bool opeAudioCodec();

    //获取视频解码器上下文
    AVCodecContext * getVideoCodec();
    //获取音频解码器上下文
    AVCodecContext * getAudioCodec();

    //获取视频流帧的像素格式
    int getPixelFormat();

    //获取视频的宽
    float getVideoWidth();

    //获取视频的高
	float getVideoHight();
    int getVideoSteamIndex();
    int getAudioSteamIndex();

private:
    int _videoIndex;   //视频流在nb_streams中的索引
    int _audioIndex;   //音频流在nb_streams中的索引
    AVCodec * _videoCodec;  //视频解码器
    AVCodec * _audioCodec;  //音频解码器
	static VideoInfo * __instance;
};
#endif