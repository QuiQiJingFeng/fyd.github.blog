#include "VideoInfo.h"
VideoInfo* VideoInfo::__instance = nullptr;

VideoInfo* VideoInfo::getInstance()
{
    if (__instance == nullptr)
    {
        __instance = new (std::nothrow) VideoInfo();
    }

    return __instance;
}

void VideoInfo::dispose()
{
    delete __instance;
    __instance = nullptr;
}

bool VideoInfo::init(std::string url)
{
    //这个方法解决了截协议和解封装两个步骤
    auto pFormatCtx = VideoContext::getInstance()->getFormatContext();
    if (avformat_open_input(&pFormatCtx, url.c_str(), NULL, NULL) != 0){
        printf("Couldn't open input stream.\n");
        return false;
    }
    //获取视频文件信息
    if (avformat_find_stream_info(pFormatCtx, NULL) < 0){
        printf("Couldn't find stream information.\n");
        return false;
    }

    if (pFormatCtx->nb_streams<2){
        //流数小于2，说明这个文件音频、视频流这两条都不能保证，输入文件有错误
        printf("输入文件错误，流不足2条\n");
        return false;
    }

    //获取视频对应的steam_index
    _videoIndex = av_find_best_stream(pFormatCtx, AVMEDIA_TYPE_VIDEO, -1, -1, nullptr, 0);
    if (_videoIndex == -1){
        printf("Didn't find a video stream.\n");
        return false;
    }

    //获取音频对应的steam_index
    _audioIndex = av_find_best_stream(pFormatCtx, AVMEDIA_TYPE_AUDIO, -1, -1, nullptr, 0);
    if (_audioIndex == -1){
        printf("Didn't find a audio stream.\n");
        return false;
    }
    return true;
};

//获取视频码率 视频码率就是数据传输时单位时间传送的数据位数，一般我们用的单位是kbps即千位每秒。通俗一点的理解就是取样率
//单位kb/s
float VideoInfo::getBitRate()
{
    auto pFormatCtx = VideoContext::getInstance()->getFormatContext();
    return pFormatCtx->bit_rate / 1000;
}

//获取视频总时长 字符串型
//@needUs 是否需要将毫秒也放进去
std::string VideoInfo::getTotalTime(bool needUs)
{
    auto pFormatCtx = VideoContext::getInstance()->getFormatContext();
    if(pFormatCtx->duration != AV_NOPTS_VALUE){
        int64_t hours, mins, secs, us;
        int64_t duration = pFormatCtx->duration + (pFormatCtx->duration <= INT64_MAX - 5000 ? 5000 : 0);
        secs  = duration / AV_TIME_BASE;
        us    = duration % AV_TIME_BASE;
        mins  = secs / 60;
        secs %= 60;
        hours = mins / 60;
        mins %= 60;
        char buffer [50];
        if(needUs)
            sprintf (buffer, "%02d:%02d:%02d.%02d\n", hours, mins, secs, (100 * us) / AV_TIME_BASE);
        else
            sprintf (buffer, "%02d:%02d:%02d\n", hours, mins, secs);
        return buffer;
    }
    return "N/A";
}

//打开视频解码器
bool VideoInfo::openVideoCodec()
{
    auto pCodecCtx = getVideoCodec();
    AVCodec * pCodec = avcodec_find_decoder(pCodecCtx->codec_id);
    if (pCodec == NULL){
        printf("Video Codec not found.\n");
        return false;
    }
    if (avcodec_open2(pCodecCtx, pCodec, NULL)<0){
        printf("Could not open codec.\n");
        return false;
    }
    return true;
}

//打开音频解码器
bool VideoInfo::opeAudioCodec()
{
    auto pCodecCtx = getAudioCodec();
    AVCodec * pCodec = avcodec_find_decoder(pCodecCtx->codec_id);
    if (pCodec == NULL){
        printf("Audio Codec not found.\n");
        return nullptr;
    }
    if (avcodec_open2(pCodecCtx, pCodec, NULL)<0){
        printf("Could not open codec.\n");
        return false;
    }
    return true;
}

//获取视频解码器上下文
AVCodecContext * VideoInfo::getVideoCodec()
{   
    auto pFormatCtx = VideoContext::getInstance()->getFormatContext(); 
    AVCodecContext * pCodecCtx = pFormatCtx->streams[_videoIndex]->codec;
    return pCodecCtx;
}

//获取音频解码器上下文
AVCodecContext * VideoInfo::getAudioCodec()
{   
    auto pFormatCtx = VideoContext::getInstance()->getFormatContext();
    AVCodecContext * pCodecCtx = pFormatCtx->streams[_audioIndex]->codec;
    return pCodecCtx;
}

//获取音频采样率
int VideoInfo:getAudioSampleRate()
{
    auto pCodecCtx = getAudioCodec();
    return pCodecCtx->sample_rate();
}

//音频解码的数据格式
AVSampleFormat VideoInfo::getSampleFmt()
{
    auto pCodecCtx = getAudioCodec();
    return pCodecCtx->sample_fmt;
}

//获取声道
int VideoInfo::getChannels()
{
    auto pCodecCtx = getAudioCodec();
    return pCodecCtx->channels;
}

//根据通道数返回默认的通道布局
int64_t VideoInfo::getChannelLayout()
{
    return av_get_default_channel_layout(getChannels());
}

//获取视频流帧的像素格式
int VideoInfo::getPixelFormat()
{
    auto pCodecCtx = getVideoCodec();
    return pCodecCtx->pix_fmt;
}

//获取视频的宽
float VideoInfo::getVideoWidth()
{
    auto pCodecCtx = getVideoCodec();
    return pCodecCtx->width;
}

//获取视频的高
float VideoInfo::getVideoHight()
{
    auto pCodecCtx = getVideoCodec();
    return pCodecCtx->height;
}


int VideoInfo::getVideoSteamIndex()
{
    return _videoIndex;
}

int VideoInfo::getAudioSteamIndex()
{
    return _audioIndex;
}