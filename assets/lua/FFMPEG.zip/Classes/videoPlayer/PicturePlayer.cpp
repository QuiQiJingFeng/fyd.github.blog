#include "PicturePlayer.h"
PicturePlayer* PicturePlayer::__instance = nullptr;

PicturePlayer* PicturePlayer::getInstance()
{
    if (__instance == nullptr)
    {
        __instance = new (std::nothrow) PicturePlayer();
    }

    return __instance;
};

void PicturePlayer::dispose()
{
    delete __instance;
    __instance = nullptr;
};

PicturePlayer::PicturePlayer()
{
	_pFrame = av_frame_alloc();
	_pFrameRGBA = av_frame_alloc();
	_packet = (AVPacket *)av_malloc(sizeof(AVPacket));
   
}

PicturePlayer::~PicturePlayer()
{
    delete _image;
    av_free(_packet);
    av_frame_free(&_pFrame);
    av_frame_free(&_pFrameRGBA);
};

bool PicturePlayer::init(Node* parent)
{
    if (getParent() != parent)
    {
        this->removeFromParentAndCleanup(false);
        parent->addChild(this);
    }
    _image = new Image();
    _totalTime = 0;
    _finish = false;
    _packetTime = -1;
	_hasInit = false;

    //打开视频解码器
    if(!VideoInfo::getInstance()->openVideoCodec())
        return false;

    auto pCodecCtx = VideoInfo::getInstance()->getVideoCodec();
    //申请一块控件挂载到AVPicture上用于保存视频帧数据 PS:这里用的是RGBA格式,转换后可以直接在cocos当中使用
    unsigned char *out_buffer = (unsigned char *)av_malloc(av_image_get_buffer_size(AV_PIX_FMT_RGBA, pCodecCtx->width, pCodecCtx->height, 1));
    av_image_fill_arrays(_pFrameRGBA->data, _pFrameRGBA->linesize, out_buffer,
        AV_PIX_FMT_RGBA, pCodecCtx->width, pCodecCtx->height, 1);

    //设置原始的格式，以及转换后的格式   SWS_BICUBIC指定转换的算法
    _imgConvertCtx = sws_getContext(pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt,
    pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_RGBA, SWS_BICUBIC, NULL, NULL, NULL);  

    return true;
}

bool PicturePlayer::nextFrame()
{
    int videoIndex = VideoInfo::getInstance()->getVideoSteamIndex();
    auto pFormatCtx = VideoContext::getInstance()->getFormatContext(); 
    while (1){
        if (av_read_frame(pFormatCtx, _packet) < 0)
        {
            _finish = true;
            return false;
        }

        if (_packet->stream_index == videoIndex)
            break;
    }
    AVStream *stream = pFormatCtx->streams[_packet->stream_index];
    _packetTime = _packet->pts * av_q2d(stream->time_base);
    return true;
};

bool PicturePlayer::parsePacket()
{
    auto pCodecCtx = VideoInfo::getInstance()->getVideoCodec();
    int ret = avcodec_decode_video2(pCodecCtx, _pFrame, &_gotPicture, _packet);
    if (ret < 0){
        CCLOG("Decode Error.\n");
        _finish = true;
        return false;
    }
    if (_gotPicture)
    {
        //转换帧数据 为RGBA格式
        sws_scale(_imgConvertCtx, (const unsigned char* const*)_pFrame->data, _pFrame->linesize, 0, pCodecCtx->height, _pFrameRGBA->data, _pFrameRGBA->linesize);
        if (!_hasInit)
        {
            _hasInit = true;
            bool isOK = _image->initWithRawData(_pFrameRGBA->data[0], (ssize_t)_pFrameRGBA->linesize, pCodecCtx->width, pCodecCtx->height, 8);
            CCASSERT(isOK, "init Raw Data Failed!!!");
			auto texture2D = new (std::nothrow) Texture2D();
			texture2D->initWithImage(_image);
			texture2D->autorelease();

			initWithTexture(texture2D);
            Size visibleSize = Director::getInstance()->getVisibleSize();
            Vec2 origin = Director::getInstance()->getVisibleOrigin();
            setContentSize(Size(pCodecCtx->width, pCodecCtx->height));
            setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            float scale = 0;
            if (scale < visibleSize.width / pCodecCtx->width){
                scale = visibleSize.width / pCodecCtx->width;
            }
            if (scale < visibleSize.height / pCodecCtx->height){
                scale = visibleSize.height / pCodecCtx->height;
            }
            setScale(scale);
        }
        else
        {
            bool isOK = _image->updateWithRawData(_pFrameRGBA->data[0], (ssize_t)_pFrameRGBA->linesize, pCodecCtx->width, pCodecCtx->height, 8);
            CCASSERT(isOK, "init Raw Data Failed!!!");
            getTexture()->initWithImage(_image);
        }
    }
    av_free_packet(_packet);
    _packetTime = -1;
    return true;
};
void PicturePlayer::step(float dt)
{
    if(_finish){
        return;
    }
    _totalTime = _totalTime + dt;
	if (_packetTime == -1){
		if (!nextFrame())
			return;
	}
	if (_totalTime > _packetTime)
	{
		if (!parsePacket())
			return;
	}
};