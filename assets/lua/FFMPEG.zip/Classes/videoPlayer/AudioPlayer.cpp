#include "AudioPlayer.h"
#include "VideoInfo.h"
AudioPlayer* AudioPlayer::__instance = nullptr;
AudioPlayer* AudioPlayer::getInstance()
{
    if (__instance == nullptr)
    {
        __instance = new (std::nothrow) AudioPlayer();
    }

    return __instance;
}

void AudioPlayer::dispose()
{
    delete __instance;
    __instance = nullptr;
}

AudioPlayer::AudioPlayer()
{
   _pFrame = av_frame_alloc();
   _packet = (AVPacket *)av_malloc(sizeof(AVPacket));
}

AudioPlayer::~AudioPlayer()
{
    av_free(_packet);
    av_frame_free(&_pFrame);
};

bool AudioPlayer::init(Node* parent)
{
    if (getParent() != parent)
    {
        this->removeFromParentAndCleanup(false);
        parent->addChild(this);
    }
    auto pACodecCtx = VideoInfo::getInstance()->getAudioCodec();
    _swr_covert_ctx = swr_alloc_set_opts(NULL, av_get_default_channel_layout(pACodecCtx->channels), AV_SAMPLE_FMT_S16, pACodecCtx->sample_rate, av_get_default_channel_layout(pACodecCtx->channels), pACodecCtx->sample_fmt, pACodecCtx->sample_rate, 0, NULL);//转换上下文
	swr_init(_swr_covert_ctx);//初始化上下文
    int samplessize = av_samples_get_buffer_size(NULL, pACodecCtx->channels, pACodecCtx->sample_rate, AV_SAMPLE_FMT_S16, 1);//计算1s的数据大小，使缓冲区足够大
    _sambuf = (uint8_t*)av_mallocz(samplessize);
}
 

bool AudioPlayer::nextFrame()
{
    int audioIndex = VideoInfo::getInstance()->getAudioSteamIndex();
    auto pFormatCtx = VideoContext::getInstance()->getFormatContext(); 
    while (1){
        if (av_read_frame(pFormatCtx, _packet) < 0)
        {
            _finish = true;
            return false;
        }

        if (_packet->stream_index == audioIndex)
            break;
    }
    AVStream *stream = pFormatCtx->streams[_packet->stream_index];
    _packetTime = _packet->pts * av_q2d(stream->time_base);
    return true;
};

bool AudioPlayer::parsePacket()
{
    auto pCodecCtx = VideoInfo::getInstance()->getAudioCodec();
    int ret = avcodec_decode_audio4(pCodecCtx, _pFrame, &_gotAudio, _packet);
    if (ret < 0){
        CCLOG("Decode Error.\n");
        _finish = true;
        return false;
    }
    if (_gotAudio)
    {
		int samplenums = swr_convert(_swr_covert_ctx, &_sambuf, samplessize, (const uint8_t **)_pFrame->data, _pFrame->nb_samples);//转换，返回每个通道的样本数
        if(samplenums > 0)
        {
            int data_size = av_samples_get_buffer_size(NULL, _pFrame->channels, samplenums, AV_SAMPLE_FMT_S16, 1)
        }
 
    }
    av_free_packet(_packet);
    _packetTime = -1;
    return true;
};
void AudioPlayer::step(float dt)
{
    if(_finish){
        return;
    }
    _totalTime = _totalTime + dt;
	if (_packetTime == -1){
		if (!nextFrame())
			return;
	}
	if (_totalTime > _packetTime)
	{
		if (!parsePacket())
			return;
	}
};