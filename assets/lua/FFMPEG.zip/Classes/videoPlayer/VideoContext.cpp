#include "VideoContext.h"
VideoContext* VideoContext::__instance = nullptr;

VideoContext* VideoContext::getInstance()
{
    if (__instance == nullptr)
    {
        __instance = new (std::nothrow) VideoContext();
    }

    return __instance;
}

VideoContext::VideoContext()
{
    //初始化libavformat并注册所有muxer、demuxer和协议.  如果不调用此函数，则可以选择您希望支持的格式
    av_register_all();
    //对网络组件进行全局初始化
    avformat_network_init();
    //创建一个AVFormatContext上下文环境
    _pFormatCtx = avformat_alloc_context();
}

bool VideoContext::init()
{
    return true;
}

AVFormatContext	* VideoContext::getFormatContext()
{
	return _pFormatCtx;
}

void VideoContext::dispose()
{
    delete VideoContext::__instance;
    VideoContext::__instance = nullptr;
    avformat_free_context(_pFormatCtx);
}