#ifndef __PICTURE_PLAYER_H
#define __PICTURE_PLAYER_H
#include "cocos2d.h"
USING_NS_CC;
#include "VideoInfo.h"

class PicturePlayer : public cocos2d::Sprite
{
public:
    static PicturePlayer* getInstance();
    void dispose();

    PicturePlayer();
    ~PicturePlayer();

    bool init(Node* parent);
 
    bool nextFrame();
    bool parsePacket();
    void step(float dt);
    inline bool isFinish() { return _finish;}

 
private:
    Image * _image;
    float _totalTime;
    float _packetTime;
    AVPacket * _packet;
    bool _finish;
    AVFrame	* _pFrame;
	AVFrame * _pFrameRGBA;
    struct SwsContext * _imgConvertCtx;
    int _gotPicture;
	bool _hasInit;
	static PicturePlayer * __instance;
};
#endif