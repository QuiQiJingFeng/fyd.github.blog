require("functions")
local CardCombination = class("CardCombination")
local constant = require "constant"
local CARD_TO_SOLOT_IDX = constant.CARD_TO_SOLOT_IDX
local SOLOT_IDX_TO_CARD = constant.SOLOT_IDX_TO_CARD
local LOG_DEBUG = true
function CardCombination:ctor(cards)
	self._steps = nil
	self:initWithCards(cards)
end

function CardCombination:initCardSolot(maxSlot)
	local solots = {}
	for idx = 1,maxSlot do
		solots[idx] = 0
	end
	self._slots = solots
end

function CardCombination:initWithCards(cards)
	self:initCardSolot(15)
	for _,cardValue in ipairs(cards) do
		local slotIdx = self:convertCardValueToSlotIdx(cardValue)
		self._slots[slotIdx] = self._slots[slotIdx] + 1
	end
	self._cards = cards
end

--public
function CardCombination:combinate(cards)
	self:combinateGroups()
	--权重值越大牌越好
	return self._steps,self:getWightByGroup(self._steps),self:caculateGroupStep(self._steps)
end

function CardCombination:combinateGroups(steps)
	steps = steps or {}
	local list = self:splitGruops()
	local tempSteps = clone(steps)
	for i,v in ipairs(list) do
		table.insert(tempSteps,v)
	end
	if not self._steps or self:compare(self._steps,tempSteps) < 0 then
		self._steps = tempSteps
	else
		return
	end

	self:feiji(steps)
	self:shunzi(steps)
	self:liandui(steps)
end

function CardCombination:splitGruops()
	local steps = {}
	local startSlotIdx = self:convertCardValueToSlotIdx(3)
	local endSlotIdx = self:convertCardValueToSlotIdx(2)

	local CONVERT_TYPE = { [1] = 'A',[2] = 'AA',[3] = 'AAA',[4] = 'AAAA' }
	for slotIdx = startSlotIdx, endSlotIdx do
		local cardNum = self:getCardNumBySlotIdx(slotIdx)
		if (cardNum > 0 and cardNum < 5) then
			local cardValue = self:getCardValueBySlotIdx(slotIdx)
			local obj = {}
			obj.type = CONVERT_TYPE[cardNum]
			obj.info = {['A'] = cardValue}
			table.insert(steps,obj)
		end
	end

	local cardValueXiaoWang = 14
	local cardValueDaWang = 15
	local numXiaoWang = self:getCardNumByCardValue(cardValueXiaoWang)
	local numDaWang = self:getCardNumByCardValue(cardValueDaWang)
	if numXiaoWang > 0 and numDaWang > 0 then
		local obj = {}
		obj.type = 'AB'
		obj.info = { ['A'] = cardValueXiaoWang, ['B'] = cardValueDaWang}
		table.insert(steps,obj)
		
	elseif numXiaoWang > 0 then
	 	local obj = {}
		obj.type = 'A'
		obj.info = {['A'] = cardValueXiaoWang }
		table.insert(steps,obj)
		
	elseif numDaWang > 0 then
		local obj = {}
		obj.type = 'A'
		obj.info = {['A'] = cardValueDaWang }
		table.insert(steps,obj)
	end

	return steps
end

function CardCombination:feiji(steps)
	local startSlotIdx = self:convertCardValueToSlotIdx(3)
	local endSlotIdx = self:convertCardValueToSlotIdx(13)
	--飞机起始值可能为3~K之中的一个值
	for start = startSlotIdx,endSlotIdx do
	   local length = 0
	   --2不参与飞机
	   while true do
	   	   local slotIdx = start + length
	       local cardNum = self:getCardNumBySlotIdx(slotIdx)
	       local maxSlotIdx = self:convertCardValueToSlotIdx(1)
	       if not (cardNum >= 3 and slotIdx <= maxSlotIdx) then
       		  break
	       end
	       length = length + 1
	   end
	   
	   ----[start - end] [start - (end - 1)] ...将所有可以构成飞机的抽出来
	   for len = length,2,-1 do
	   	   local _end = start + len - 1
	       for slotIdx = start,_end do
	           self._slots[slotIdx] = self._slots[slotIdx] - 3 
	       end
	       local obj = {}
	       local temp = {}
	       local typeInfo = {}
	       for slotIdx = start,_end do
	       	  local char = string.char(slotIdx-start + 65)
	       	  local cardValue = self:getCardValueBySlotIdx(slotIdx)
	       	  typeInfo[char] = cardValue
	       	  for i=1,3 do
	       	  	  table.insert(temp,char)
	       	  end
	       end
	       obj.type = table.concat(temp)
	       obj.info = typeInfo

	       local newSteps = clone(steps)
	       table.insert(newSteps,obj)
	       self:combinateGroups(newSteps)
	       for slotIdx = start,_end do
	           self._slots[slotIdx] = self._slots[slotIdx] + 3 
	       end
	   end
	end
end

function CardCombination:liandui(steps)
    local length, _end
	local startSlotIdx = self:convertCardValueToSlotIdx(3)
	local endSlotIdx = self:convertCardValueToSlotIdx(12)
    for start = startSlotIdx, endSlotIdx do
        length = 0
        while true do
        	local slotIdx = start + length
        	local cardNum = self:getCardNumBySlotIdx(slotIdx)
        	local maxSlotIdx = self:convertCardValueToSlotIdx(1)
        	if not (cardNum >= 2 and slotIdx <= maxSlotIdx) then
        		break
        	end
        	length = length + 1
        end
        --连对 [start-end] [start-(end-1)]
        --连对至少要3对
        for len = length, 3, -1 do
            _end = start + len - 1
            for slotIdx = start, _end, 1 do
                self._slots[slotIdx] = self._slots[slotIdx] - 2
            end

            local obj = {}
	        local temp = {}
	        local typeInfo = {}
 
            for slotIdx = start, _end, 1 do
	            local char = string.char(slotIdx-start + 65)
                local cardValue = self:getCardValueBySlotIdx(slotIdx)
                typeInfo[char] = cardValue
                for i=1,2 do
            		table.insert(temp,char)
            	end
            end
            obj.type = table.concat(temp)
            obj.info = typeInfo

            local newSteps = clone(steps)
            table.insert(newSteps,obj)
	       	self:combinateGroups(newSteps)

            for slotIdx = start, _end, 1 do
                self._slots[slotIdx] = self._slots[slotIdx] + 2
            end
        end
    end
end

function CardCombination:shunzi(steps)
    local length, _end
	local startSlotIdx = self:convertCardValueToSlotIdx(3)
	local endSlotIdx = self:convertCardValueToSlotIdx(10)
    for start = startSlotIdx, endSlotIdx do
        length = 0
        while true do
        	local slotIdx = start + length
        	local cardNum = self:getCardNumBySlotIdx(slotIdx)
        	local maxSlotIdx = self:convertCardValueToSlotIdx(1)
        	if not (cardNum >= 1 and slotIdx <= maxSlotIdx) then
        		break
        	end
        	length = length + 1
        end

        for len = length, 5, -1 do
            _end = start + len - 1
            for slotIdx = start, _end, 1 do
                self._slots[slotIdx] = self._slots[slotIdx] - 1
            end

            local obj = {}
	        local temp = {}
	        local typeInfo = {}
            for slotIdx = start, _end, 1 do
	            local char = string.char(slotIdx-start + 65)
                local cardValue = self:getCardValueBySlotIdx(slotIdx)
		       	table.insert(temp,char)
		       	typeInfo[char] = cardValue
            end
            obj.type = table.concat(temp)
            obj.info = typeInfo

            local newSteps = clone(steps)
            table.insert(newSteps,obj)
	       	self:combinateGroups(newSteps)
            for slotIdx = start, _end, 1 do
                self._slots[slotIdx] = self._slots[slotIdx] + 1
            end
        end
    end
end

function CardCombination:convertCurrentSolotsToCardList()
	local cardList = {}
  	for slotIdx,num in ipairs(self._slots) do
  		local cardValue = self:getCardValueBySlotIdx(slotIdx)
  		for i=1,num do
  			table.insert(cardList,cardValue)
  		end
  	end
  	return cardList
end

--@static  
function CardCombination:getSerialCardListByGiveObj(obj)
	local list = string.split(obj.type,'-')
	local strMahorType = list[1]
	local strExtral = list[2]

	--连续牌的个数,例如AAABBB-CCDD 就是2
	local serialNum = string.byte(strMahorType,#strMahorType,#strMahorType) - 64
	--单张连续个数例如AAA 就是3
	local num = #strMahorType / serialNum
	local targetCardValue = obj.info['B']

	local objList = {}
	local targetSlotIdx = self:convertCardValueToSlotIdx(targetCardValue)
	local firstSlotIdx = self:convertCardValueToSlotIdx(3)
	local endSlotIdx = self:convertCardValueToSlotIdx(13)
	local boomList = {}
	--飞机起始值可能为3~K之中的一个值
	for start = firstSlotIdx,endSlotIdx do
		local cardNum = self:getCardNumBySlotIdx(start)
		local cardValue = self:getCardValueBySlotIdx(start)
		if cardNum >= 4 then
			local boomObj = {info= { ['A'] = cardValue },type = 'AAAA'}
			table.insert(boomList,boomObj)
		end

	    if start >= targetSlotIdx then
		   local length = 0
		   --2不参与飞机、连对、顺子
		   while true do
		   	   local slotIdx = start + length
		       local cardNum = self:getCardNumBySlotIdx(slotIdx)
		       local maxSlotIdx = self:convertCardValueToSlotIdx(1)
		       --炸弹不拆
		       if not (cardNum >= num and cardNum ~= 4 and slotIdx <= maxSlotIdx) then
	       		  break
		       end
		       length = length + 1
		   end
		   if length >= serialNum then
		      ----[start - end] [start - (end - 1)] ...将所有可以构成飞机的抽出来
		   	   local _end = start + serialNum - 1
		       local newObj = {}
		       local temp = {}
		       local typeInfo = {}
		       for slotIdx = start,_end do
		       	  local char = string.char(slotIdx-start + 65)
		       	  local cardValue = self:getCardValueBySlotIdx(slotIdx)
		       	  typeInfo[char] = cardValue
		       	  for i=1,num do
		       	  	  table.insert(temp,char)
		       	  end
		       end
		       for slotIdx = start, _end, 1 do
			       for i=1,num do
	               		self._slots[slotIdx] = self._slots[slotIdx] - 1
	               	end
	           end

	            --去掉连续牌之后的手牌
	          	local cardList = self:convertCurrentSolotsToCardList()
	          	local cardCombinator = CardCombination.new(cardList)
	          	--获取此时最佳手牌
	          	local finalSteps = cardCombinator:combinate()
		       --带牌,带牌可能带单和双,因为双也可以代表两个单
		       local extralCards = {}
		       if strExtral then
		          	--从最佳手牌中获取足够的带牌
		          	local extralCards = self:getExtralCardByFinalSteps(finalSteps,obj.type)
	          		if extralCards then
	          			local lastCharCode = temp[#temp]
	          			table.insert(temp,"-")
	          			for i=1,#strExtral do
	          				local code = string.byte(strExtral,i,i)
	          				local char = string.char(code)
	          				table.insert(temp,char)
	          				typeInfo[char] = extralCards[i]
	          			end
	          			newObj.type = table.concat(temp)
		       			newObj.info = typeInfo
	          			table.insert(objList,newObj)
	      			end
		       else
		       	   newObj.type = table.concat(temp)
			       newObj.info = typeInfo
		       	   table.insert(objList,newObj)
		       end

		       for slotIdx = start, _end, 1 do
	                for i=1,num do
	               		self._slots[slotIdx] = self._slots[slotIdx] + 1
	               	end
	            end
		   end
		end
	end
	for _,boom in ipairs(boomList) do
		boom.wight = -1000
		table.insert(objList,boom)
	end
	--王炸可以管上任何牌型
	local cardValueXiaoWang = 14
	local cardValueDaWang = 15
	local numXiaoWang = self:getCardNumByCardValue(cardValueXiaoWang)
	local numDaWang = self:getCardNumByCardValue(cardValueDaWang)
	if numXiaoWang > 0 and numDaWang > 0 then
		huojianObj = {}
		huojianObj.info = {['A'] = cardValueXiaoWang,['B'] = cardValueDaWang}
		huojianObj.wight = -1000
		huojianObj.type = 'AB'
		table.insert(objList,huojianObj)
	end
	return objList
end

function CardCombination:getExtralCardByFinalSteps(finalSteps,objType)
	local list = string.split(objType,'-')
	local strMahorType = list[1]
	local strExtral = list[2]
	--连续牌的个数,例如AAABBB-CCDD 就是2
	local serialNum = string.byte(strMahorType,#strMahorType,#strMahorType) - 64
	--需要的数量,可以是数量的两倍(对子)
	local needCardNum = #strExtral
    --从最佳手牌中获取足够的带牌,如果不够则拆对牌,拆大于5的长连 其他的不允许拆
  	local canExtralSteps = {}
  	for _,step in ipairs(finalSteps) do
  		--带的是对子
  		if #strExtral == 2 * serialNum then
  			if step.type == 'AA' then
      			table.insert(canExtralSteps,step)
      		end
  		else
  			if step.type == 'A' or step.type == 'AA' then
      			table.insert(canExtralSteps,step)
      		end
  		end
  	end

  	--排序,牌数多的在后面，相同牌数的牌值小的在前面
	table.sort(canExtralSteps,function(a,b)
			--这里需要把不同张数的差异扩大，所以用了指数
			local aValue = self:convertCardValueToSlotIdx(a.info['A']) * 10 ^(#a.type)
			local bValue = self:convertCardValueToSlotIdx(b.info['A']) * 10 ^(#b.type)
			return aValue < bValue
		end)
	local extralCards = {}
	--开始取带牌
	for _,step in ipairs(canExtralSteps) do
		for i=1,#step.type do
			local char = string.char(string.byte(step.type,i,i))
			local value = step.info[char]
			table.insert(extralCards,value)
			if #extralCards >= needCardNum then
				break
			end
		end
		if #extralCards >= needCardNum then
			break
		end
	end
	if #extralCards < needCardNum then
		return false
	end

	return extralCards
end

--[[
	找到比指定牌型大的牌,按照牌组的权重进行排序,权重小的小牌排前面
	最后补上炸弹和王炸
]]
function CardCombination:getSingleCardListByGiveObj(obj)
	local list = string.split(obj.type,'-')
	local strMahorType = list[1]
	local strExtral = list[2]
	local needCardNum = #strMahorType
	local targetCardValue = obj.info['A']

	local targetList = {}
	local tempList = {}
	local targetSlotIdx = self:convertCardValueToSlotIdx(targetCardValue)
	local firstSlotIdx = self:convertCardValueToSlotIdx(3)
	local endSlotIdx = self:convertCardValueToSlotIdx(15)
	local boomList = {}
	--遍历查找大于指定牌型的牌
	for start = firstSlotIdx,endSlotIdx do
		local cardNum = self:getCardNumBySlotIdx(start)
		local cardValue = self:getCardValueBySlotIdx(start)
		if cardNum >= 4 then
			if obj.type == 'AAAA' and start > targetSlotIdx then
				local boomObj = {info= { ['A'] = cardValue },type = 'AAAA'}
				table.insert(boomList,{obj = boomObj})
			end
			if obj.type ~= 'AAAA' then
				local boomObj = {info= { ['A'] = cardValue },type = 'AAAA'}
				table.insert(boomList,{obj = boomObj})
			end
		end
		for i=1,1 do
			if start > targetSlotIdx and cardNum >= needCardNum then
				if obj.type ~= 'AAAA-BC' and obj.type ~= 'AAAA-BBCC' and cardNum == 4 then
					break
				end
				local newObj = {}
				newObj.info = {}
				newObj.type = obj.type
				newObj.info['A'] = cardValue
				--去掉指定的牌型
			    for i=1,needCardNum do
	           		self._slots[start] = self._slots[start] - 1
	            end
	            local cardList = self:convertCurrentSolotsToCardList()
				local cardCombinator = CardCombination.new(cardList)
			  	local finalSteps,_,stepNum = cardCombinator:combinate()
			  	local wight = 1000 - stepNum
			  	if LOG_DEBUG then
			  		local outList = {}
			  		for i,step in ipairs(finalSteps) do
			  			local strGroupValue = self:convertCardGroupToString(step)
			  			table.insert(outList,strGroupValue)
			  		end
			  		print(string.format('[%d] wight=[%s] =>%s',cardValue,wight,table.concat(outList," ")))
			  	end

				if strExtral then
				  	local extralCards = self:getExtralCardByFinalSteps(finalSteps,obj.type)
				  	if extralCards then
					  	for i=1,#strExtral do
							local char = string.char(string.byte(strExtral,i,i))
							newObj.info[char] = extralCards[i]
						end
					  	table.insert(tempList,{obj = newObj,wight = wight})
					end
				else
					table.insert(tempList,{obj = newObj,wight = wight})
				end
				--补回来指定的牌型
				for i=1,needCardNum do
	           		self._slots[start] = self._slots[start] + 1
	            end
			end
		end
	end

	for _,boom in ipairs(boomList) do
		boom.wight = -1000
		table.insert(tempList,boom)
	end

	--王炸可以管上任何牌型
	local cardValueXiaoWang = 14
	local cardValueDaWang = 15
	local numXiaoWang = self:getCardNumByCardValue(cardValueXiaoWang)
	local numDaWang = self:getCardNumByCardValue(cardValueDaWang)
	if numXiaoWang > 0 and numDaWang > 0 then
		local huojianObj = {}
		huojianObj.obj = {}
		huojianObj.obj.info = {['A'] = cardValueXiaoWang,['B'] = cardValueDaWang}
		huojianObj.wight = -1000
		huojianObj.obj.type = 'AB'
		table.insert(tempList,huojianObj)
	end

	--出牌后剩余权重大的排前边
	table.sort(tempList,function(a,b)
			if a.wight == b.wight then
				local aSlot = self:convertCardValueToSlotIdx(a.obj.info['A'])
				local bSlot = self:convertCardValueToSlotIdx(b.obj.info['A'])
				return aSlot < bSlot
			end
			return a.wight > b.wight
		end)

 	for i,temp in ipairs(tempList) do
 		table.insert(targetList,temp.obj)
 	end
 
 	return targetList
end

--假如按出牌张数作为权重
local GROUP_TYPE_WIDGHT = {
	['A'] = function(maxCard) return maxCard - 8 end,
	['AA'] = function(maxCard)
		local value = maxCard - 8
		if value > 0 then
			value = value * 1.5
		end
		return value
	end,
	['AAA'] = function(maxCard)
		local value = maxCard - 8 
		if value > 0 then
			value = value * 2
		end
		return value
	end,
	['ABCDE'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['ABCDEF'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['ABCDEFG'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['ABCDEFGH'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['ABCDEFGHI'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['ABCDEFGHIJ'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['ABCDEFGHIJK'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['ABCDEFGHIJKL'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,

	['AABBCC'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['AABBCCDD'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['AABBCCDDEE'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['AABBCCDDEEFF'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['AABBCCDDEEFFGG'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['AABBCCDDEEFFGGHH'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,

	['AAABBB'] = function(maxCard)  return math.max(0,(maxCard - 8)/2) end,
	['AAABBBCCC'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['AAABBBCCCDDD'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,
	['AAABBBCCCDDDEEE'] = function(maxCard) return math.max(0,(maxCard - 8)/2) end,

	['AAAA'] = 9,
	['AB'] = 12,
}

--计算组的step,算上三带1这种,4带2
function CardCombination:caculateGroupStep(group)
	local groupNum = #group
	local danList = {}
	local duiList = {}
	for i,obj in ipairs(group) do
		if obj.type == 'A' then
			table.insert(danList,obj)
		elseif obj.type == 'AA' then
			table.insert(duiList,obj)
		end
	end
	local extralNum = 0
	for i,obj in ipairs(group) do
		--优先满足带牌数量多的
		if string.find(obj.type,"AAABBB") then
			--如果是飞机
			local majorType = string.split(obj.type,"-")[1] 
			local num = (#majorType)/3
			if #danList >= num then
				for i=1,num do
					table.remove(danList)
				end
				extralNum = extralNum + num
			elseif #duiList >= num then
				for i=1,num do
					table.remove(duiList)
				end
				extralNum = extralNum + num
			elseif #danList + 2*#duiList >= num then
				for i=1,num do
					local obj = table.remove(danList)
					if not obj then
						obj = table.remove(duiList)
						table.insert(danList,obj.info['A'])
					end
				end
				extralNum = extralNum + num
			end
			
		elseif obj.type == "AAA" then
			--如果是三带1
			if #danList + #duiList >= 1 then
				if #danList > #duiList then
					table.remove(danList)
				else
					table.remove(duiList)
				end
				extralNum = extralNum + 1
			end
		end
	end

	return groupNum - extralNum
end

local STEP_WIDGHT = {6,6,6,5,5,5,4,4,4,3}
function CardCombination:getWightByGroup(group)
	local wight = 0
	for _,step in ipairs(group) do
 		local response = GROUP_TYPE_WIDGHT[step.type]
 		if type(response) == "function" then
 			local lastChar = string.char(string.byte(step.type,#step.type))
 			local cardValue = step.info[lastChar]
 			local slotIdx = self:convertCardValueToSlotIdx(cardValue)
 			wight = wight + response(slotIdx)
 		else
 			wight = wight + response
 		end
	end
	local stepNum = self:caculateGroupStep(group)
	local price = wight - STEP_WIDGHT[1] * stepNum
	return price
end

function CardCombination:compare(oldGroup,newGroup)
	local now = self:getWightByGroup(newGroup)
	local old = self:getWightByGroup(oldGroup)
	return old >= now and 1 or -1
end

function CardCombination:convertCardValueToSlotIdx(cardValue)
	return CARD_TO_SOLOT_IDX[cardValue]
end

function CardCombination:getCardValueBySlotIdx(slotIdx)
	return SOLOT_IDX_TO_CARD[slotIdx]
end

function CardCombination:getCardNumBySlotIdx(slotIdx)
	return self._slots[slotIdx]
end

function CardCombination:getCardNumByCardValue(cardValue)
	local slotIdx = self:convertCardValueToSlotIdx(cardValue)
	return self:getCardNumBySlotIdx(slotIdx)
end




--[[
	单张:A
	对子:AA
	火箭:AB
	三张:AAA
	三带一:AAA-B
	三带一对:AAA-BB
	炸弹:AAAA
	炸弹带2张:AAAA-BB/AAAA-BC
	炸弹带两对:AAAABBCC
	单顺:ABCDE...
	双顺:AABBCCDD...
	飞机:AAABBB
	飞机带两张:AAABBB-CC/AAABBB-CD
	飞机带两对:AAABBB-CCDD
]]
--返回类型,并且返回每个类型中字符对应的牌值
function CardCombination:checkCardGroupType(cards)
	if #cards == 1 then
		return {type = "A", info = {A = cards[1]} }
	end
	--排序,张数多的在前面
	local cardNumMap = {}
	for i,v in ipairs(cards) do
		cardNumMap[v] = cardNumMap[v] and cardNumMap[v] + 1 or 1
	end
	table.sort(cards,function(a,b)
			if cardNumMap[a] == cardNumMap[b] then
				return a < b
			end
			return cardNumMap[a] > cardNumMap[b]
		end)
	local startType = 65
	local cardType = {}
	local cardTypeInfo = {}
	local preCard
	for _,card in ipairs(cards) do
		if not preCard then
			local charType = string.char(startType)
			table.insert(cardType,charType)
			cardTypeInfo[charType] = card
			preCard = card
		elseif preCard ~= card then
			startType = startType + 1
			local charType = string.char(startType)
			table.insert(cardType,charType)
			cardTypeInfo[charType] = card
			preCard = card
		else
			local charType = string.char(startType)
			table.insert(cardType,charType)
		end
	end
	 
	local strType = self:splitUnSerialCharWithChar(table.concat(cardType))
 	return {type = strType, info = cardTypeInfo}
end

--以指定字符分割不连续的字符处 例如AAABBBCD 分割为AAABBB-CD
function CardCombination:splitUnSerialCharWithChar(strType)
	local function getSerialChar(char,num)
		local temp = {}
		for i=1,num do
			table.insert(temp,char)
		end
		return table.concat(temp)
	end
	local firstCharCode = 65
	local num = 0
	for i=1,#strType do
		if string.byte(strType,i,i) == firstCharCode then
			num = num + 1
		end
	end
	local code = firstCharCode - 1
	local splitPos
	while true do
		local strSerialChar = getSerialChar(string.char(code + 1),num)
		local _,pos = string.find(strType,strSerialChar)
		if not pos then
			break
		end
		splitPos = pos
		code = code + 1
	end
	local preStr = string.sub(strType,1,splitPos)
	local endStr = string.sub(strType,splitPos + 1)
	local insertChar = '-'
	if endStr ~= "" then
		strType = preStr .. insertChar .. endStr
	end
	return strType
end

--检查出牌提示   putCard =>	3,3,3,4,4,4
function CardCombination:checkCardGroupTips(putCards)
	local cardList = self._cards
	if LOG_DEBUG then
		print("putCard =>",table.concat(putCards,","))
		print("cardList =>",table.concat(cardList,","))
	end
	local obj = self:checkCardGroupType(putCards)

	local list = string.split(obj.type,'-')
	local strMahorType = list[1]
	local strExtral = list[2]


	--连续牌的个数,例如AAABBB-CCDD 就是2
	local serialNum = string.byte(strMahorType,#strMahorType,#strMahorType) - 64

	--顺子、连对、飞机
	local biggerGroups = {}
	if serialNum > 1 then
		biggerGroups = self:getSerialCardListByGiveObj(obj)
	elseif serialNum == 1 then
		biggerGroups = self:getSingleCardListByGiveObj(obj)
	else
		assert(false)
	end

	if LOG_DEBUG then
		local outList = {}
		for _,step in ipairs(biggerGroups) do
			local strGroupValue = self:convertCardGroupToString(step)
			table.insert(outList,strGroupValue)
		end
		print("OUTPUT:")
		print(table.concat(outList,","))
	end

	return biggerGroups
end

function CardCombination:convertCardGroupToString(step)
	local strGroupValue = step.type
	for key,value in pairs(step.info) do
		strGroupValue = string.gsub(strGroupValue,key,value..",")
	end
	strGroupValue = string.gsub(strGroupValue,'-',"-> ")
	strGroupValue = '['..string.sub(strGroupValue,1,#strGroupValue - 1) ..']'
	
	return strGroupValue
end

return CardCombination