

--测试单张
local function testCase1()
	local CardCombination = require "CardCombination"
	local handCardList = {2,2,1,1,1,13,11,4,4}
	local cardCombinator = CardCombination.new(handCardList)
	print("===========================")
	cardCombinator:checkCardGroupTips({10,10,10,11})
	print("===========================")
end


testCase1()

