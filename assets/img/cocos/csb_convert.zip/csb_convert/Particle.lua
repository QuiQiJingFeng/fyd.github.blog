local xml = require("xml")
local BaseNode = require("BaseNode")
local Particle = class("Particle",BaseNode)

function Particle:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
 	local particleSystemOptions = nodeInfo.particleSystemOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,
 
					ctype = "ParticleObjectData"
				})

	Particle.super.ctor(self,nodeInfo,doc)

	if particleSystemOptions then
		local obj = xml.new("FileData",{ 
			Type = "Normal",
			Path = particleSystemOptions.fileNameData.path or "",
			Plist = particleSystemOptions.fileNameData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
	end
	local obj = xml.new("BlendFunc",{ Src = 1, Dst = 771})
    table.insert(self._propertys,obj)  
 
	self:addBaseProperty(doc)
end

return Particle