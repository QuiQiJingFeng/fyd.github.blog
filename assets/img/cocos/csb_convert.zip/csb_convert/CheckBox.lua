local xml = require("xml")
local BaseNode = require("BaseNode")
local CheckBox = class("CheckBox",BaseNode)

function CheckBox:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
 	local checkBoxOptions = nodeInfo.checkBoxOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,

					
					CheckedState= checkBoxOptions.selectedState,
					TouchEnable = "True",

					ctype = "CheckBoxObjectData"
				})

	CheckBox.super.ctor(self,nodeInfo,doc)

 
 	if checkBoxOptions and checkBoxOptions.backGroundBoxData then
 		local obj = xml.new("NormalBackFileData",{ 
			Type = (checkBoxOptions.backGroundBoxData.plistFile and checkBoxOptions.backGroundBoxData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = checkBoxOptions.backGroundBoxData.path or ""
			Plist = checkBoxOptions.backGroundBoxData.plistFile or ""
		})
	    table.insert(self._propertys,obj)  
 	end

 	if checkBoxOptions and checkBoxOptions.backGroundBoxSelectedData then
 		local obj = xml.new("PressedBackFileData",{ 
			Type = (checkBoxOptions.backGroundBoxSelectedData.plistFile and checkBoxOptions.backGroundBoxSelectedData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = checkBoxOptions.backGroundBoxSelectedData.path or ""
			Plist = checkBoxOptions.backGroundBoxSelectedData.plistFile or ""
		})
	    table.insert(self._propertys,obj)  
 	end

 	if checkBoxOptions and checkBoxOptions.backGroundBoxDisabledData then
 		local obj = xml.new("DisableBackFileData",{ 
			Type = (checkBoxOptions.backGroundBoxDisabledData.plistFile and checkBoxOptions.backGroundBoxDisabledData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = checkBoxOptions.backGroundBoxDisabledData.path or ""
			Plist = checkBoxOptions.backGroundBoxDisabledData.plistFile or ""
		})
	    table.insert(self._propertys,obj)  
 	end

 	if checkBoxOptions and checkBoxOptions.backGroundBoxData then
 		local obj = xml.new("NodeNormalFileData",{ 
			Type = (checkBoxOptions.backGroundBoxData.plistFile and checkBoxOptions.backGroundBoxData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = checkBoxOptions.backGroundBoxData.path or ""
			Plist = checkBoxOptions.backGroundBoxData.plistFile or ""
		})
	    table.insert(self._propertys,obj)  
 	end

 	if checkBoxOptions and checkBoxOptions.backGroundBoxSelectedData then
 		local obj = xml.new("NodeDisableFileData",{ 
			Type = (checkBoxOptions.backGroundBoxSelectedData.plistFile and checkBoxOptions.backGroundBoxSelectedData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = checkBoxOptions.backGroundBoxSelectedData.path or ""
			Plist = checkBoxOptions.backGroundBoxSelectedData.plistFile or ""
		})
	    table.insert(self._propertys,obj)  
 	end
 
	self:addBaseProperty(doc)
end

return CheckBox