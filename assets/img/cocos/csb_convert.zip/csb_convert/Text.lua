local xml = require("xml")
local BaseNode = require("BaseNode")
local Text = class("Text",BaseNode)

function Text:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
	local textOptions = nodeInfo.textOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,

					LabelText = textOptions.text or "",
 
					ctype = "TextObjectData"
				})

	Text.super.ctor(self,nodeInfo,doc)

	if textOptions and textOptions.fontResource then
 		local obj = xml.new("FontResource",{ 
			Type = "Normal",
			Path = textOptions.fontResource.path or "",
			Plist = textOptions.fontResource.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end
 

	self:addBaseProperty(doc)
end

return Text