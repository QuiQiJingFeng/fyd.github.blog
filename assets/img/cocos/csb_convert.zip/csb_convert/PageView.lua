local xml = require("xml")
local BaseNode = require("BaseNode")
local PageView = class("PageView",BaseNode)

function PageView:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
 
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,

					BackColorAlpha="102",
					ColorAngle="90.0000",
					ScrollDirectionType="0",
 
					ctype = "PageViewObjectData"
				})

	PageView.super.ctor(self,nodeInfo,doc)

	 

 	local obj = xml.new("SingleColor",{ A = 255, R = 150, G = 200, B = 255})
    table.insert(self._propertys,obj)  
    local obj = xml.new("FirstColor",{ A = 255, R = 150, G = 200, B = 255})
    table.insert(self._propertys,obj)  
    local obj = xml.new("EndColor",{ A = 255, R = 255, G = 255, B = 255})
    table.insert(self._propertys,obj)  
    local ColorVector = xml.new("ColorVector",{ ScaleY="1.0000"})
    table.insert(self._propertys,obj)  

 

	self:addBaseProperty(doc)
end

return PageView