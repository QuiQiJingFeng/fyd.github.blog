local xml = require("xml")
local BaseNode = class("BaseNode")
--[[
<Position X="10.0000" Y="12.0000" />
<Scale ScaleX="1.0000" ScaleY="1.0000" />
<CColor A="255" R="255" G="255" B="255" />
<PrePosition />
<PreSize X="0.0000" Y="0.0000" />
]]
function BaseNode:ctor(nodeInfo,doc)
    	local widgetOptions =  nodeInfo.widgetOptions
    	assert(widgetOptions)
      self._children = {}
    	self._propertys = {}
      --Size
      local obj = xml.new("Size",{X = widgetOptions.width,Y = widgetOptions.height})
      doc:add_child(obj)

      --AnchorPoint
      if widgetOptions.anchorPointX and widgetOptions.anchorPointY then
           local obj = xml.new("AnchorPoint",{ScaleX = widgetOptions.anchorPointX,ScaleY = widgetOptions.anchorPointY})
           table.insert(self._propertys,obj)
      end
      --Position
      if widgetOptions.x and widgetOptions.y then
            local obj = xml.new("Position",{ X = widgetOptions.x, Y = widgetOptions.y})
            table.insert(self._propertys,obj)  
      end
      --Scale
      if widgetOptions.scaleX and widgetOptions.scaleY then
            local obj = xml.new("Scale",{ ScaleX = widgetOptions.scaleX, ScaleY = widgetOptions.scaleY})
            table.insert(self._propertys,obj)  
      end

      if widgetOptions.colorR and widgetOptions.colorG and widgetOptions.colorB and widgetOptions.Alpha then
            local obj = xml.new("CColor",{ A = widgetOptions.Alpha, R = widgetOptions.colorR, G = widgetOptions.colorG, B = widgetOptions.colorB})
            table.insert(self._propertys,obj)  
      end
      local obj = xml.new("PrePosition",{})
      table.insert(self._propertys,obj)
      local obj = xml.new("PreSize",{ X = 0,Y = 0})
      table.insert(self._propertys,obj)

      

      self._doc = doc
      if nodeInfo.children and #nodeInfo.children > 0 then
          self._childContainer = xml.new("Children",{})
          self._doc:add_child(self._childContainer)
      end
end

function BaseNode:getDoc()
      return self._doc
end

function BaseNode:addBaseProperty(doc)

      for i,obj in ipairs(self._propertys) do
          doc:add_child(obj)
      end
end

function BaseNode:addChild(node)
      local idx = table.indexof(self._children,node)
      assert(not idx)
      table.insert(self._children,node)
      local nodeDoc = node:getDoc()
      self._childContainer:add_child(nodeDoc)
end

function BaseNode:tostring()
    return xml.tostring(self._doc)
end

return BaseNode