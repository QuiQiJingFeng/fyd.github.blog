local xml = require("xml")
local BaseNode = require("BaseNode")
local Node = class("Node",BaseNode)

function Node:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "True",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,
					ctype = "SingleNodeObjectData"
				})

	Node.super.ctor(self,nodeInfo,doc)

	
	
	self:addBaseProperty(doc)
end

return Node