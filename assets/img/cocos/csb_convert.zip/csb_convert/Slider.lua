local xml = require("xml")
local BaseNode = require("BaseNode")
local Slider = class("Slider",BaseNode)

function Slider:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
 	local sliderOptions = nodeInfo.sliderOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,

 
					ProgressInfo= sliderOptions.percent,
					Scale9Enable = sliderOptions.scale9Enable,
 					Scale9Width = sliderOptions.scale9Width or sliderOptions.capInsetsWidth,
 					Scale9Height = sliderOptions.scale9Height or sliderOptions.capInsetsHeight,
 					Scale9OriginX = sliderOptions.capInsetsX,
 					Scale9OriginY = sliderOptions.capInsetsY,
					ctype = "SliderObjectData"
				})

	Slider.super.ctor(self,nodeInfo,doc)
 
 	if sliderOptions and sliderOptions.barFileNameData then
 		local obj = xml.new("BackGroundData",{ 
			Type = (sliderOptions.barFileNameData.plistFile and sliderOptions.barFileNameData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = sliderOptions.barFileNameData.path or "",
			Plist = sliderOptions.barFileNameData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	if sliderOptions and sliderOptions.progressBarData then
 		local obj = xml.new("ProgressBarData",{ 
			Type = (sliderOptions.progressBarData.plistFile and sliderOptions.progressBarData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = sliderOptions.progressBarData.path or "",
			Plist = sliderOptions.progressBarData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	if sliderOptions and sliderOptions.ballNormalData then
 		local obj = xml.new("BallNormalData",{ 
			Type = (sliderOptions.ballNormalData.plistFile and sliderOptions.ballNormalData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = sliderOptions.ballNormalData.path or "",
			Plist = sliderOptions.ballNormalData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	if sliderOptions and sliderOptions.ballPressedData then
 		local obj = xml.new("BallPressedData",{ 
			Type = (sliderOptions.ballPressedData.plistFile and sliderOptions.ballPressedData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = sliderOptions.ballPressedData.path or "",
			Plist = sliderOptions.ballPressedData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	if sliderOptions and sliderOptions.ballDisabledData then
 		local obj = xml.new("BallDisabledData",{ 
			Type = (sliderOptions.ballDisabledData.plistFile and sliderOptions.ballDisabledData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = sliderOptions.ballDisabledData.path or "",
			Plist = sliderOptions.ballDisabledData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	 
 
	self:addBaseProperty(doc)
end

return Slider