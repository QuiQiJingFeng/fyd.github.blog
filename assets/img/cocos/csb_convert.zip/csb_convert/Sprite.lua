local xml = require("xml")
local BaseNode = require("BaseNode")
local Sprite = class("Sprite",BaseNode)

function Sprite:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
	local spriteOptions = nodeInfo.spriteOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,

					FlipX = spriteOptions.flipX,
					FlipY = spriteOptions.flipY,
					ctype = "SpriteObjectData"
				})

	Sprite.super.ctor(self,nodeInfo,doc)

	if spriteOptions and spriteOptions.fileNameData then
		local obj = xml.new("FileData",{ 
			Type = spriteOptions.useMergedTexture and "MarkedSubImage" or "Normal",
			Path = spriteOptions.fileNameData.path or "",
			Plist = spriteOptions.fileNameData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
	end
	local obj = xml.new("BlendFunc",{ Src = 1, Dst = 771})
    table.insert(self._propertys,obj)  


	self:addBaseProperty(doc)
end

return Sprite