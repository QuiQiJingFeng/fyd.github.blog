local xml = require("xml")
local BaseNode = require("BaseNode")
local TextBMFont = class("TextBMFont",BaseNode)

function TextBMFont:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
 	local textBMFontOptions = nodeInfo.textBMFontOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,

					
					LabelText= textBMFontOptions.text,
 

					ctype = "TextBMFontObjectData"
				})

	TextBMFont.super.ctor(self,nodeInfo,doc)
 
 	if textBMFontOptions and textBMFontOptions.fileNameData then
 		local obj = xml.new("LabelBMFontFile_CNB",{ 
			Type = "Normal",
			Path = textBMFontOptions.fileNameData.path or "",
			Plist = "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	 
 
	self:addBaseProperty(doc)
end

return TextBMFont