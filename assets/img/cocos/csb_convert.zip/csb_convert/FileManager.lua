require("functions")
local lfs = require "lfs"
local sep = string.match (package.config, "[^\n]+")

local FileManager = {}

function FileManager:joinPath(...)
	local args = {...}
	for i,value in ipairs(args) do
		value = self:normalPath(value)
		local lastChar = string.sub(value,#value,#value)
		if lastChar == sep then
			value = string.sub(value,1,#value-1)
		end
		args[i] = value
	end
	
	return table.concat(args,sep)
end

function FileManager:normalPath(path)
	local is_windows = sep == "\\"
	if is_windows then
		path = string.gsub(path,"/",sep)
	end
	return path
end

--递归遍历文件夹
function FileManager:walkDir(dirPath,filters,callBack)
	assert(dirPath)
	assert(callBack)
	for file in lfs.dir(dirPath) do
		if file ~= "." and file ~= ".." then
		   local path = self:joinPath(dirPath,file)
		   local attr = lfs.attributes(path)
		   assert (type(attr) == "table")
		   if attr.mode == "directory" then
		       self:walkDir(path,filters,callBack)
		   else
		   	   if filters then
			   	   for i,filter in ipairs(filters) do
			   	   	   if string.find(path,filter) then
			   	   	   	  callBack(path,attr)
			   	   	   	  break
			   	   	   end
			   	   end
			   	else
				    callBack(path,attr)
			    end
		   end
		end
	end
end

function FileManager:getDataFromFile(path)
	local file = io.open(path,"rb")
	local content = file:read("*a")
	file:close()
	return content
end

function FileManager:writeDataToFile(path,content)
	local file = io.open(path,"wb")
	file:write(content)
	file:close()
end

function FileManager:getCurrentDirectory()
	return lfs.currentdir()
end

function FileManager:removeDirectory(dir)
	lfs.rmdir(dir)
end

function FileManager:makeDirectory(dir)
	lfs.mkdir(dir)
end

function FileManager:isWindows()
	return sep == "\\"
end

function FileManager:removeFile(path)
	return os.remove(path)
end

return FileManager