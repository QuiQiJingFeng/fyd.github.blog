local xml = require("xml")
local BaseNode = require("BaseNode")
local Button = class("Button",BaseNode)

function Button:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
 	local buttonOptions = nodeInfo.buttonOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,

 					Scale9Enable = buttonOptions.scale9Enable,
 					Scale9Width = buttonOptions.scale9Width or buttonOptions.capInsetsWidth,
 					Scale9Height = buttonOptions.scale9Height or buttonOptions.capInsetsHeight,
 					Scale9OriginX = buttonOptions.capInsetsX,
 					Scale9OriginY = buttonOptions.capInsetsY,
 					TouchEnable = "True",
					ctype = "ButtonObjectData"
				})

	Button.super.ctor(self,nodeInfo,doc)

	if buttonOptions and buttonOptions.textColorR then
		local obj = xml.new("TextColor",{ R = buttonOptions.textColorR, G = buttonOptions.textColorG, B = buttonOptions.textColorB})
        table.insert(self._propertys,obj) 
	end
 	if buttonOptions and buttonOptions.disabledData then
 		local obj = xml.new("DisabledFileData",{ 
			Type = (buttonOptions.fileNameData and buttonOptions.fileNameData.plistFile and buttonOptions.fileNameData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = (buttonOptions.fileNameData and buttonOptions.fileNameData.path) or "",
			Plist = (buttonOptions.fileNameData and buttonOptions.fileNameData.plistFile) or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	if buttonOptions and buttonOptions.pressedData then
 		local obj = xml.new("PressedFileData",{ 
			Type = (buttonOptions.pressedData.plistFile and buttonOptions.pressedData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = buttonOptions.pressedData.path or "",
			Plist = buttonOptions.pressedData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	if buttonOptions and buttonOptions.normalData then
 		local obj = xml.new("NormalFileData",{ 
			Type = (buttonOptions.normalData.plistFile and buttonOptions.normalData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = buttonOptions.normalData.path or "",
			Plist = buttonOptions.normalData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	if buttonOptions and buttonOptions.fontResource then
 		local obj = xml.new("FontResource",{ 
			Type = "Normal",
			Path = buttonOptions.fontResource.path or "",
			Plist = buttonOptions.fontResource.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end
 

    local obj = xml.new("OutlineColor",{ A="255",R="255",G="0",B="0"})
    table.insert(self._propertys,obj)  

	local obj = xml.new("ShadowColor",{ A="255",R="110",G="110",B="110"})
    table.insert(self._propertys,obj)  
 
	self:addBaseProperty(doc)
end

return Button