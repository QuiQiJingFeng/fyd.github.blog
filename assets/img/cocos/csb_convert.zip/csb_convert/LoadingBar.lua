local xml = require("xml")
local BaseNode = require("BaseNode")
local LoadingBar = class("LoadingBar",BaseNode)

function LoadingBar:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
 	local loadingBarOptions = nodeInfo.loadingBarOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "False",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,

 
					ProgressInfo= loadingBarOptions.percent,
					Scale9Enable = loadingBarOptions.scale9Enable,
 					Scale9Width = loadingBarOptions.scale9Width or loadingBarOptions.capInsetsWidth,
 					Scale9Height = loadingBarOptions.scale9Height or loadingBarOptions.capInsetsHeight,
 					Scale9OriginX = loadingBarOptions.capInsetsX,
 					Scale9OriginY = loadingBarOptions.capInsetsY,
					ctype = "LoadingBarObjectData"
				})

	LoadingBar.super.ctor(self,nodeInfo,doc)
 
 	if loadingBarOptions and loadingBarOptions.textureData then
 		local obj = xml.new("ImageFileData",{ 
			Type = (loadingBarOptions.textureData.plistFile and loadingBarOptions.textureData.plistFile~= "") and "MarkedSubImage" or "Normal",
			Path = loadingBarOptions.textureData.path or "",
			Plist = loadingBarOptions.textureData.plistFile or "",
		})
	    table.insert(self._propertys,obj)  
 	end

 	 
 
	self:addBaseProperty(doc)
end

return LoadingBar