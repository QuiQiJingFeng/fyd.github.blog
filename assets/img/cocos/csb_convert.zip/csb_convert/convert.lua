local FileManager = require("FileManager")
local json = require("json")
local xml = require("xml")
local dirPath = "C:/Users/Administrator/Desktop/tools/BREAKOUT/BREAKOUT_SLOTGAME/BREAKOUT_SLOTGAME/res"
local filters = {".json"}

local current_id = 0x4f1d6279b700
local function get_uid()
  current_id = current_id + 1
  return ('a2ee0952-26b5-49ae-8bf9-%012x'):format(current_id)
end

local function get_root_type(root_node)
    if root_node.classname == 'Node' then
      return 'Node'
    else
      return 'Scene'
    end
end

local CONVERT_FRAME_TYPE = {
	["PositionFrame"] = "Position",
	["ScaleFrame"] = "Scale",
	["RotationSkewFrame"] = "RotationSkew",
	["ColorFrame"] = "CColor",
	["TextureFrame"] = "FileData",
	["VisibleFrame"] = "VisibleForFrame",
}

local function parseAnimation(action,doc)
	local docAnim = xml.new("Animation",{Duration=action.duration,Speed=action.speed})
	if action.timelines and #action.timelines > 0 then
		for i,timeline in ipairs(action.timelines) do
			local frameType = CONVERT_FRAME_TYPE[timeline.frameType] or timeline.frameType
			local docTimeLine = xml.new("Timeline",{ActionTag=timeline.actionTag,Property = frameType})
			local frames = timeline.frames
			for i,info in ipairs(frames) do
				if frameType == "Position" then
					local docFrame = xml.new("PointFrame",{FrameIndex=info.positionFrame.frameIndex,X=info.positionFrame.x,Y=info.positionFrame.y})
					local docEasing = xml.new("EasingData",{Type="0"})
					docFrame:add_child(docEasing)
					docTimeLine:add_child(docFrame)
				elseif frameType == "Scale" then
					local docFrame = xml.new("ScaleFrame",{FrameIndex=info.scaleFrame.frameIndex,X=info.scaleFrame.x,Y=info.scaleFrame.y})
					local docEasing = xml.new("EasingData",{Type="0"})
					docFrame:add_child(docEasing)
					docTimeLine:add_child(docFrame)
				elseif frameType == "RotationSkew" then
					local docFrame = xml.new("ScaleFrame",{FrameIndex=info.rotationSkewFrame.frameIndex,X=info.rotationSkewFrame.x,Y=info.rotationSkewFrame.y})
					local docEasing = xml.new("EasingData",{Type="0"})
					docFrame:add_child(docEasing)
					docTimeLine:add_child(docFrame)
				elseif frameType == "CColor" then
					local docFrame = xml.new("ColorFrame",{FrameIndex=info.colorFrame.frameIndex,Alpha=info.colorFrame.alpha})
					local docEasing = xml.new("EasingData",{Type="0"})
					docFrame:add_child(docEasing)
					docTimeLine:add_child(docFrame)

					local docEasing = xml.new("Color",{A=info.colorFrame.alpha,R=info.colorFrame.red,G=info.colorFrame.green,B=info.colorFrame.blue})
					docFrame:add_child(docEasing)
				elseif frameType == "FileData" then
					local docFrame = xml.new("TextureFrame",{FrameIndex=info.textureFrame.frameIndex,Tween=info.textureFrame.tween})
					local docEasing = xml.new("TextureFile",{
						Type="Normal",
						Path= info.textureFrame.filePath,
						Plist=info.textureFrame.plistFile
					})
					docFrame:add_child(docEasing)
					docTimeLine:add_child(docFrame)
 				elseif frameType == "VisibleForFrame" then
 					local docFrame = xml.new("BoolFrame",{FrameIndex=info.visibleFrame.frameIndex,Tween=info.visibleFrame.tween,Value=info.visibleFrame.value})
					docTimeLine:add_child(docFrame)
				else
					error(frameType)
				end
			end
			docAnim:add_child(docTimeLine)
		end
	end
	doc:add_child(docAnim)
end

local function addGameProject(data)
	local rootXml = xml.new("GameProjectFile",{})
	local rootType = get_root_type(data)
	local doc = xml.new("PropertyGroup",{Type=rootType,Name=rootType,ID=get_uid(),Version="2.3.1.2"})
	rootXml:add_child(doc)
	contentXml = xml.new("Content",{ctype="GameProjectContent"})
	rootXml:add_child(contentXml)
	contentXml2 = xml.new("Content",{})
	contentXml:add_child(contentXml2)

	parseAnimation(data.action,contentXml2)
 

	local ObjectDataXML = xml.new('ObjectData', {
		ctype = "GameNodeObjectData",
		Name  = data.nodeTree.widgetOptions.name,
		Tag   = data.nodeTree.widgetOptions.tag or -110,
	})
	local childDoc = xml.new("Size",{X=data.nodeTree.widgetOptions.width, Y=data.nodeTree.widgetOptions.height})
	ObjectDataXML:add_child(childDoc)
	contentXml2:add_child(ObjectDataXML)

	childXml = xml.new("Children",{})
	ObjectDataXML:add_child(childXml)
	return rootXml,childXml
end

local CONVERT_MAP = {
	["SingleNode"] = "Node"
}

local parseChild
parseChild = function(nodeInfo)
	local classname = CONVERT_MAP[nodeInfo.classname] or nodeInfo.classname
	local path = classname .. ".lua"
	assert(io.exists(path),path.." not exists "..json.encode(nodeInfo))
	local cls = require(classname)
	local obj = cls.new(nodeInfo)
	if nodeInfo.children and #nodeInfo.children > 0 then
		for i,child in ipairs(nodeInfo.children) do
			local childObj = parseChild(child)
			obj:addChild(childObj)
		end
	end
	return obj
end
 
local removeList = {}
FileManager:walkDir(dirPath,filters,function(path,attr)
	local pathPre = string.gsub(path,"%.json","")
	local csbPath = pathPre .. ".csb"
	local jsonPath = pathPre .. ".json"
	local csdPath = pathPre .. ".csd"
	local pngPath = pathPre .. ".png"
	if io.exists(csbPath) then
		if not io.exists(csdPath) then
			print(jsonPath)
			local content = FileManager:getDataFromFile(jsonPath)
			local data = json.decode(content)
			local rootXml,childXml = addGameProject(data)
			local children = data.nodeTree.children
			for i,child in ipairs(children) do
				local childObj = parseChild(child)
				local childDoc = childObj:getDoc()
				childXml:add_child(childDoc)
			end
 
			local rootContent = xml.tostring(rootXml, '', '  '):sub(2, -1)
			FileManager:writeDataToFile(csdPath,rootContent)

			table.insert(removeList,csbPath)
			table.insert(removeList,jsonPath)
			table.insert(removeList,pngPath)
		end
	end
end)

for i,path in ipairs(removeList) do
	FileManager:removeFile(path)
end
print("SUCCESS")