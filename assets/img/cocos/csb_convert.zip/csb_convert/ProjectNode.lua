local xml = require("xml")
local BaseNode = require("BaseNode")
local ProjectNode = class("ProjectNode",BaseNode)

function ProjectNode:ctor(nodeInfo)
	local widgetOptions = nodeInfo.widgetOptions
	local layoutParameter = widgetOptions.layoutParameter
	local projectNodeOptions = nodeInfo.projectNodeOptions
	local doc = xml.new("AbstractNodeData",{
					Name = widgetOptions.name, 
					ActionTag = widgetOptions.actionTag, 
					Tag = widgetOptions.tag, 
					Rotation = widgetOptions.rotationSkewX,
					RotationSkewX = widgetOptions.rotationSkewX,
					RotationSkewY = widgetOptions.rotationSkewY, 
					VisibleForFrame = widgetOptions.visible and "True" or "False",
					IconVisible = "True",
					LeftMargin = layoutParameter and layoutParameter.marginLeft or nil,
					RightMargin = layoutParameter and layoutParameter.marginRight or nil,
					TopMargin = layoutParameter and layoutParameter.marginTop or nil,
					BottomMargin = layoutParameter and layoutParameter.marginDown or nil,
					ctype = "ProjectNodeObjectData"
				})

	ProjectNode.super.ctor(self,nodeInfo,doc)


	if projectNodeOptions and projectNodeOptions.fileNameData then
		local obj = xml.new("FileData",{ 
			Type = "Normal",
			Path = projectNodeOptions.path or "",
			Plist = "",
		})
	    table.insert(self._propertys,obj)  
	end

	
	
	self:addBaseProperty(doc)
end

return ProjectNode